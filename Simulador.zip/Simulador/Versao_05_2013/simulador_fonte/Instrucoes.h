#ifndef INSTRUCOES_H
#define INSTRUCOES_H

class Instrucoes
{	public:
		virtual void updateInstrucoes(unsigned int atual, unsigned int proxima, unsigned int linhas) = 0;
};

#endif
